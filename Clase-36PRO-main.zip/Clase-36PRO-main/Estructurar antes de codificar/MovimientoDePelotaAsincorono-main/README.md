# MovimientoDePelotaAsincorono
Boilerplate para movimiento de la pelota de forma asíncrona
